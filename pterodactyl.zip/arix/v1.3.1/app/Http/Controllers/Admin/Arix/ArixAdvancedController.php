<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Prologue\Alerts\AlertsMessageBag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class ArixAdvancedController extends Controller
{
    public function __construct(
        private ViewFactory $view,
        private SettingsRepositoryInterface $settings,
        private AlertsMessageBag $alert
    ) {
    }

    public function index()
    {
        return $this->view->make('admin.arix.advanced', [
            'profileType' => $this->settings->get('arix:profileType', 'boring'),
            'ipFlag' => $this->settings->get('arix:ipFlag', 'false'),
            'lowResourcesAlert' => $this->settings->get('arix:lowResourcesAlert', 'false'),
            'modeToggler' => $this->settings->get('arix:modeToggler', 'false'),
            'langSwitch' => $this->settings->get('arix:langSwitch', 'false'),
        ]);
    }

    public function store(Request $request)
    {
        foreach ($request->except('_token') as $key => $value) {
            if (str_starts_with($key, 'arix:')) {
                $this->settings->set($key, $value ?? 'false');
            }
        }

        $this->alert->success('Advanced settings have been updated.')->flash();
        return Redirect::route('admin.arix.advanced');
    }
}