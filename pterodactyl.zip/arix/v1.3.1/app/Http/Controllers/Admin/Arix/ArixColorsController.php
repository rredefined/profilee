<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Prologue\Alerts\AlertsMessageBag; // Import Alert Service
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class ArixColorsController extends Controller
{
    /**
     * ArixColorsController constructor.
     */
    public function __construct(
        private ViewFactory $view,
        private SettingsRepositoryInterface $settings,
        private AlertsMessageBag $alert // Inject Alert Service di sini
    ) {
    }

    public function index()
    {
        $colors = [
            'primary', 'successText', 'successBorder', 'successBackground',
            'dangerText', 'dangerBorder', 'dangerBackground',
            'secondaryText', 'secondaryBorder', 'secondaryBackground',
            'gray50', 'gray100', 'gray200', 'gray300', 'gray400',
            'gray500', 'gray600', 'gray700', 'gray800', 'gray900',
            'lightmode_primary', 'lightmode_successText', 'lightmode_successBorder', 'lightmode_successBackground',
            'lightmode_dangerText', 'lightmode_dangerBorder', 'lightmode_dangerBackground',
            'lightmode_secondaryText', 'lightmode_secondaryBorder', 'lightmode_secondaryBackground',
            'lightmode_gray50', 'lightmode_gray100', 'lightmode_gray200', 'lightmode_gray300', 'lightmode_gray400',
            'lightmode_gray500', 'lightmode_gray600', 'lightmode_gray700', 'lightmode_gray800', 'lightmode_gray900'
        ];

        $data = [];
        foreach ($colors as $color) {
            // Default ke #000000 biar aman
            $data[$color] = $this->settings->get('arix:' . $color, '#000000');
        }

        return $this->view->make('admin.arix.colors', $data);
    }

    public function store(Request $request)
    {
        // Ambil input kecuali _token
        $inputs = $request->except('_token');

        foreach ($inputs as $key => $value) {
            if (str_starts_with($key, 'arix:')) {
                // Pastikan value aman (tidak null)
                $safeValue = $value ?? '#000000'; 
                $this->settings->set($key, $safeValue);
            }
        }

        // Sekarang $this->alert udah bisa dipake karena udah di-inject
        $this->alert->success('Color settings have been updated.')->flash();

        return Redirect::route('admin.arix.colors');
    }
}