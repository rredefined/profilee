<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Prologue\Alerts\AlertsMessageBag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class ArixLayoutController extends Controller
{
    public function __construct(
        private ViewFactory $view,
        private SettingsRepositoryInterface $settings,
        private AlertsMessageBag $alert
    ) {
    }

    public function index()
    {
        return $this->view->make('admin.arix.layout', [
            'layout' => $this->settings->get('arix:layout', '1'),
            'searchComponent' => $this->settings->get('arix:searchComponent', '1'),
            'loginLayout' => $this->settings->get('arix:loginLayout', '1'),
            'socialPosition' => $this->settings->get('arix:socialPosition', '1'),
            'logoPosition' => $this->settings->get('arix:logoPosition', '1'),
        ]);
    }

    public function store(Request $request)
    {
        foreach ($request->except('_token') as $key => $value) {
            if (str_starts_with($key, 'arix:')) {
                $this->settings->set($key, $value ?? '1');
            }
        }

        $this->alert->success('Layout settings have been updated.')->flash();
        return Redirect::route('admin.arix.layout');
    }
}