<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Prologue\Alerts\AlertsMessageBag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class ArixMetaController extends Controller
{
    public function __construct(
        private ViewFactory $view,
        private SettingsRepositoryInterface $settings,
        private AlertsMessageBag $alert
    ) {
    }

    public function index()
    {
        return $this->view->make('admin.arix.meta', [
            'meta_favicon' => $this->settings->get('arix:meta_favicon', ''),
            'meta_title' => $this->settings->get('arix:meta_title', 'Pterodactyl'),
            'meta_image' => $this->settings->get('arix:meta_image', ''),
            'meta_description' => $this->settings->get('arix:meta_description', ''),
            'meta_color' => $this->settings->get('arix:meta_color', '#000000'),
        ]);
    }

    public function store(Request $request)
    {
        foreach ($request->except('_token') as $key => $value) {
            if (str_starts_with($key, 'arix:')) {
                $this->settings->set($key, $value ?? '');
            }
        }

        $this->alert->success('Meta settings have been updated.')->flash();
        return Redirect::route('admin.arix.meta');
    }
}